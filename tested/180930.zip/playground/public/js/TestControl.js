﻿// == manager ==
var TestControl = function() {
    this.curfunc   = null;
    this.nextfunc  = null;
    this.candfunc  = null;
    this.nowait    = false;    
};
TestControl.prototype.update = function() {
    while(true)
    {
        this.nowait = false;

        var first = false;
        if (this.nextfunc!=null) {
            this.curfunc  = this.nextfunc;
            this.nextfunc = null;
            first = true;
        }
        if (this.curfunc!=null) {
            this.curfunc(first);
        }

        if (!this.nowait) break;
    }
};
TestControl.prototype.checkstate = function(st) {
    return this.candfunc === st;
};
TestControl.prototype.goto = function(st) {
    this.nextfunc = st;
};
TestControl.prototype.setnext = function(st) {
    this.candfunc = st;
}
TestControl.prototype.gonext = function() {
    this.nextfunc = this.candfunc;
    this.candfunc = null;
}
TestControl.prototype.hasnext = function() {
    return this.candfunc!=null;
}
TestControl.prototype.setnowait = function() {
    this.nowait = true;
}
TestControl.prototype.start = function() {
        this.goto(this.S_START);
};
TestControl.prototype.is_end = function() {
        return this.checkstate(this.S_END);
};
// == yesno set ==
TestControl.yesno=false;
TestControl.prototype.br_yes = function(st) {
        if (!this.hasnext(st)) {
                if (this.yesno) {
                        this.setnext(st);
                }
        }
};
TestControl.prototype.br_no = function(st) {
        if (!this.hasnext(st)) {
                if (!this.yesno) {
                        this.setnext(st);
                }
        }
};

// [SYN-G-GEN OUTPUT START] $/./$
//  psggConverterLib.dll converted from TestControl.xlsx. 
    /*
        S_END
    */
    TestControl.prototype.S_END = function(first) {
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END2
        new state
    */
    TestControl.prototype.S_END2 = function(first) {
        if (first)
        {
            console.log("S_END2");
        }
        if (!this.hasnext()) {
            this.setnext(this.S_END);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END3
        new state
    */
    TestControl.prototype.S_END3 = function(first) {
        if (first)
        {
            console.log("S_END3");
        }
        if (!this.hasnext()) {
            this.setnext(this.S_END);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END4
        new state
    */
    TestControl.prototype.S_END4 = function(first) {
        if (first)
        {
            console.log("S_END4");
        }
        if (!this.hasnext()) {
            this.setnext(this.S_END);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END5
        new state
    */
    TestControl.prototype.S_END5 = function(first) {
        if (first)
        {
            this.yesno=false;
        }
        this.br_yes( this.S_END6 );
        this.br_no( this.S_END7 );
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END6
        new state
    */
    TestControl.prototype.S_END6 = function(first) {
        if (first)
        {
            console.log("S_END6");
        }
        if (!this.hasnext()) {
            this.setnext(this.S_END);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_END7
        new state
    */
    TestControl.prototype.S_END7 = function(first) {
        if (first)
        {
            console.log("S_END7");
        }
        if (!this.hasnext()) {
            this.setnext(this.S_END);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };
    /*
        S_START
    */
    TestControl.prototype.S_START = function(first) {
        if (!this.hasnext()) {
            this.setnext(this.S_END5);
        }
        if (this.hasnext()) {
            this.gonext();
        }
    };


// [SYN-G-GEN OUTPUT END]

// == write your code ==

